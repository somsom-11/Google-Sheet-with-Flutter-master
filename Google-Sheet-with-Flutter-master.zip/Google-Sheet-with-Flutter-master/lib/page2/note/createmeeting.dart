//import 'package:Google_Sheet_with_Flutter/page2/note/note.dart';
//import 'package:flutter/material.dart';
//
//class createMeet extends StatefulWidget{
//  @override
//  _createMeet createState() => _createMeet();
//}
//class _createMeet extends State<createMeet>{
//  @override
//  final teName = TextEditingController();
//  final teEmail = TextEditingController();
//  final teAge = TextEditingController();
//  final teMobile = TextEditingController();
//  DateTime dateTime = DateTime.now();
//  TimeOfDay timeOfDay = TimeOfDay.now();
//  User user;
//  static const TextStyle linkStyle = const TextStyle(
//    color: Colors.blue,
//    decoration: TextDecoration.underline,
//  );
////  Widget build(BuildContext context){
////    AddUserCallback _myHomePageState, bool isEdit, User user) {
////    if (user != null) {
////    this.user = user;
////    teName.text = user.name;
////    teEmail.text = user.email;
////    teAge.text = user.age;
////    teMobile.text = user.mobile;
////    }
////
////
////  }
//
//}
